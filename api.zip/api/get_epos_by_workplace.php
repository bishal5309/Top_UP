<?php
header('Content-Type: application/json');

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_mcash";
$password = "your_db_password";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

// Fetch all top-up logs
$sql = "SELECT user_id, amount, type, workplace FROM top_up_logs ORDER BY id DESC"; // id DESC → latest first
$result = $conn->query($sql);

$logs = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
}

echo json_encode(['status' => 'success', 'logs' => $logs]);

$conn->close();
?>
