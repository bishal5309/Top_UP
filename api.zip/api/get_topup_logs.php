<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

// ================= Database connection =================
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'DB Connection failed']));
}

// ================= Check workplace param (POST) =================
if (!isset($_POST['workplace']) || trim($_POST['workplace']) === '') {
    echo json_encode(['status' => 'error', 'message' => 'Workplace required']);
    exit;
}

$workplace = trim($_POST['workplace']);

// ================= Fetch transactions =================
$stmt = $conn->prepare("SELECT user_id, amount, created_at FROM top_up_logs WHERE workplace = ? ORDER BY created_at DESC");
$stmt->bind_param("s", $workplace);
$stmt->execute();
$result = $stmt->get_result();

$transactions = [];

while ($row = $result->fetch_assoc()) {
    $transactions[] = [
        'user_id' => $row['user_id'],
        'amount' => $row['amount'],
        'created_at' => $row['created_at']
    ];
}

if (count($transactions) > 0) {
    echo json_encode([
        'status' => 'success',
        'transactions' => $transactions
    ]);
} else {
    echo json_encode([
        'status' => 'success',
        'transactions' => []
    ]);
}

$stmt->close();
$conn->close();
?>
