<?php
header('Content-Type: application/json');

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

// Get POST data
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$balance = isset($_POST['balance']) ? $_POST['balance'] : '';
$workplace = isset($_POST['workplace']) ? $_POST['workplace'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';

// Validate
if(empty($user_id) || empty($password) || empty($balance) || empty($workplace) || empty($address)){
    echo json_encode(['status' => 'error', 'message' => 'All fields required']);
    exit;
}

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";
$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB Connection failed']));
}

// Insert query
$stmt = $conn->prepare("INSERT INTO users (user_id, password, balance, workplace, address) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $user_id, $password, $balance, $workplace, $address);

if($stmt->execute()){
    echo json_encode(['status'=>'success','message'=>'User added']);
} else {
    echo json_encode(['status'=>'error','message'=>'Insert failed']);
}

$stmt->close();
$conn->close();
?>
