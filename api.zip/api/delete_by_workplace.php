<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

$workplace = isset($_POST['workplace']) ? trim($_POST['workplace']) : '';

if (empty($workplace)) {
    echo json_encode(['status' => 'error', 'message' => 'Workplace required']);
    exit;
}

$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";
$conn = new mysqli($host, $username, $password_db, $dbname);

if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'DB Connection failed']);
    exit;
}

// Prepare delete queries for each table
$tables = ['users', 'user_topup', 'top_up_logs']; // Add more if needed
$successCount = 0;
$failCount = 0;

foreach ($tables as $table) {
    $stmt = $conn->prepare("DELETE FROM $table WHERE workplace = ?");
    if ($stmt) {
        $stmt->bind_param("s", $workplace);
        if ($stmt->execute()) {
            $successCount += $stmt->affected_rows;
        } else {
            $failCount++;
        }
        $stmt->close();
    } else {
        $failCount++;
    }
}

$conn->close();

echo json_encode([
    'status' => $failCount === 0 ? 'success' : 'partial',
    'message' => "$successCount record(s) deleted across tables",
    'errors' => $failCount
]);
?>