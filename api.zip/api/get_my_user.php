<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Validate input
if(!isset($_GET['user_id']) || empty($_GET['user_id']) ||
   !isset($_GET['password']) || empty($_GET['password']) ||
   !isset($_GET['workplace']) || empty($_GET['workplace'])) {
    echo json_encode(['status'=>'error', 'message'=>'Missing required parameters']);
    exit;
}

$user_id = $_GET['user_id'];
$password = $_GET['password'];
$workplace = $_GET['workplace'];

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);
if($conn->connect_error){
    echo json_encode(['status'=>'error','message'=>'DB connection failed']);
    exit;
}

// Prepare and execute query to fetch only this user
$stmt = $conn->prepare("SELECT user_id, password, workplace, balance, address FROM users WHERE user_id = ? AND password = ? AND workplace = ?");
$stmt->bind_param("sss", $user_id, $password, $workplace);
$stmt->execute();
$result = $stmt->get_result();

if($result && $result->num_rows > 0){
    $user = $result->fetch_assoc();
    echo json_encode(['status'=>'success','user'=>$user]);
}else{
    echo json_encode(['status'=>'error','message'=>'User not found or invalid credentials']);
}

$stmt->close();
$conn->close();
?>
