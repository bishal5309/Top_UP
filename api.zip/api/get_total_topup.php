<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";
$conn = new mysqli($host, $username, $password_db, $dbname);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'DB Connection failed']));
}

// Check workplace param
if (!isset($_GET['workplace']) || trim($_GET['workplace']) === '') {
    echo json_encode(['status' => 'error', 'message' => 'Workplace required']);
    exit;
}

$workplace = trim($_GET['workplace']);

// Fetch total amount
$stmt = $conn->prepare("SELECT total_amount FROM user_topup WHERE workplace=?");
$stmt->bind_param("i", $workplace);
$stmt->execute();
$stmt->bind_result($totalAmount);

if ($stmt->fetch()) {
    echo json_encode(['status' => 'success', 'total_top_up' => $totalAmount]);
} else {
    echo json_encode(['status' => 'success', 'total_top_up' => 0]);
}

$stmt->close();
$conn->close();
?>
