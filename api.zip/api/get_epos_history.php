<?php
header('Content-Type: application/json');

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'DB Connection failed']));
}

// Fetch EPOS history from top_up_logs
$sql = "SELECT user_id, amount, workplace, type FROM top_up_logs ORDER BY id DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $epos_history = [];
    while ($row = $result->fetch_assoc()) {
        $epos_history[] = $row;
    }
    echo json_encode(['status' => 'success', 'epos_history' => $epos_history]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No data found']);
}

$conn->close();
?>