<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database credentials
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

// Connect to database
$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'DB Connection failed']);
    exit;
}

// Fetch latest version from app_version table
$query = "SELECT version_code FROM app_version ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode([
        'status' => 'success',
        'version_code' => $row['version_code']
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Version not found'
    ]);
}

$conn->close();
?>
