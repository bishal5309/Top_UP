<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

// Database connection (your preferred style)
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";
$conn = new mysqli($host, $username, $password_db, $dbname);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'DB Connection failed']));
}

// Validate required fields
if (!isset($_POST['user_id'], $_POST['amount'], $_POST['workplace'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

// Sanitize inputs
$user_id   = trim($_POST['user_id']);
$amount    = floatval($_POST['amount']);
$workplace = trim($_POST['workplace']);
$type      = isset($_POST['type']) ? trim($_POST['type']) : 'TOP UP';

// Validate values
if ($user_id === '' || $amount <= 0 || $workplace === '') {
    echo json_encode(["status" => "error", "message" => "Invalid input values"]);
    exit;
}

// Prepare SQL statement
$stmt = $conn->prepare("INSERT INTO top_up_logs (user_id, amount, workplace, type) VALUES (?, ?, ?, ?)");
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Prepare failed: " . $conn->error]);
    exit;
}

$stmt->bind_param("sdss", $user_id, $amount, $workplace, $type);

// Execute and respond
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "id" => $stmt->insert_id]);
} else {
    echo json_encode(["status" => "error", "message" => "Execute failed: " . $stmt->error]);
}

// Debug log
error_log("TOP UP → user_id: $user_id | amount: $amount | workplace: $workplace | type: $type");

$stmt->close();
$conn->close();
?>