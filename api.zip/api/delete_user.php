<?php
header('Content-Type: application/json');

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

// Get POST data
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';

// Validate
if(empty($user_id)){
    echo json_encode(['status'=>'error','message'=>'User ID required']);
    exit;
}

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";
$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB Connection failed']));
}

// Delete query
$stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
$stmt->bind_param("s", $user_id);

if($stmt->execute()){
    echo json_encode(['status'=>'success','message'=>'User deleted']);
} else {
    echo json_encode(['status'=>'error','message'=>'Delete failed']);
}

$stmt->close();
$conn->close();
?>
