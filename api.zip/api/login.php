<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

$user_id = $_POST['user_id'] ?? '';
$password = $_POST['password'] ?? '';
$workplace = $_POST['workplace'] ?? '';

if(empty($user_id) || empty($password) || empty($workplace)){
    echo json_encode(['status'=>'error','message'=>'All fields required']);
    exit;
}

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB Connection failed']));
}

// Check user with status
$stmt = $conn->prepare("SELECT password, workplace, status FROM users WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows > 0){
    $stmt->bind_result($db_password, $db_workplace, $db_status);
    $stmt->fetch();

    if($db_status === 'blocked'){
        echo json_encode(['status'=>'error','message'=>'Your account is blocked']);
        $stmt->close();
        $conn->close();
        exit;
    }

    if($password === $db_password){ // production এ hash ব্যবহার করো
        if($workplace === $db_workplace){
            echo json_encode(['status'=>'success','message'=>'Login successful']);
        } else {
            echo json_encode(['status'=>'error','message'=>'Workplace mismatch']);
        }
    } else {
        echo json_encode(['status'=>'error','message'=>'Invalid password']);
    }
} else {
    echo json_encode(['status'=>'error','message'=>'User not found']);
}

$stmt->close();
$conn->close();
?>
