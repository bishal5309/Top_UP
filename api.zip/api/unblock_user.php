<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status'=>'error','message'=>'Invalid request']);
    exit;
}

$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';

if (empty($user_id)) {
    echo json_encode(['status'=>'error','message'=>'User ID required']);
    exit;
}

$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB connection failed']));
}

$stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
if ($stmt->execute()) {
    echo json_encode(['status'=>'success','message'=>'User unblocked']);
} else {
    echo json_encode(['status'=>'error','message'=>'Unblock failed']);
}
$stmt->close();
$conn->close();
?>
