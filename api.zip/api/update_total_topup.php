<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB Connection failed']));
}

if (!isset($_POST['workplace'], $_POST['amount'])) {
    echo json_encode(['status'=>'error','message'=>'Missing fields']);
    exit;
}

$workplace = intval($_POST['workplace']);
$amount = floatval($_POST['amount']);

// check if row exists
$stmt = $conn->prepare("SELECT total_amount FROM user_topup WHERE workplace=?");
$stmt->bind_param("i", $workplace);
$stmt->execute();
$stmt->bind_result($currentAmount);
$stmt->fetch();
$stmt->close();

if ($currentAmount !== null) {
    // update existing row
    $newAmount = $currentAmount + $amount;
    $update = $conn->prepare("UPDATE user_topup SET total_amount=? WHERE workplace=?");
    $update->bind_param("di", $newAmount, $workplace);
    $update->execute();
    $update->close();
} else {
    // insert new row
    $newAmount = $amount;
    $insert = $conn->prepare("INSERT INTO user_topup (workplace, total_amount) VALUES (?,?)");
    $insert->bind_param("id", $workplace, $newAmount);
    $insert->execute();
    $insert->close();
}

echo json_encode(['status'=>'success','total_top_up'=> $newAmount]);

$conn->close();
?>
