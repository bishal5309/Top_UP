<?php
header('Content-Type: application/json');

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

// Get POST data
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';
$balance = isset($_POST['balance']) ? $_POST['balance'] : '';
$deduct = isset($_POST['deduct']) ? $_POST['deduct'] : ''; // ✅ New field for deduction

// Database connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";
$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB Connection failed']));
}

// ------------------- Overwrite Balance (existing logic) -------------------
if (!empty($user_id) && !empty($balance)) {
    $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE user_id = ?");
    $stmt->bind_param("ss", $balance, $user_id);

    if($stmt->execute()){
        echo json_encode(['status'=>'success','message'=>'Balance updated']);
    } else {
        echo json_encode(['status'=>'error','message'=>'Update failed']);
    }

    $stmt->close();
    $conn->close();
    exit;
}

// ------------------- Deduct Balance (new logic) -------------------
if (!empty($user_id) && !empty($deduct)) {
    $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ?");
    $stmt->bind_param("ds", $deduct, $user_id);

    if($stmt->execute()){
        echo json_encode(['status'=>'success','message'=>'Balance deducted']);
    } else {
        echo json_encode(['status'=>'error','message'=>'Deduction failed']);
    }

    $stmt->close();
    $conn->close();
    exit;
}

// If nothing matched
echo json_encode(['status'=>'error','message'=>'Missing required fields']);
?>