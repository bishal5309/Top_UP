<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status'=>'error','message'=>'Invalid request']);
    exit;
}

$version = isset($_POST['version_code']) ? $_POST['version_code'] : '';
if(empty($version)){
    echo json_encode(['status'=>'error','message'=>'Version required']);
    exit;
}

// DB connection
$host = "localhost";
$dbname = "sbetsho1_mcash_db";
$username = "sbetsho1_admin_user";
$password_db = "sequerepass123";

$conn = new mysqli($host, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die(json_encode(['status'=>'error','message'=>'DB Connection failed']));
}

// Check if row exists
$result = $conn->query("SELECT id FROM app_version LIMIT 1");
if($result->num_rows > 0){
    // Update existing
    $stmt = $conn->prepare("UPDATE app_version SET version_code = ?");
    $stmt->bind_param("i",$version);
} else {
    // Insert new
    $stmt = $conn->prepare("INSERT INTO app_version (version_code) VALUES (?)");
    $stmt->bind_param("i",$version);
}

if($stmt->execute()){
    echo json_encode(['status'=>'success','message'=>'Version updated']);
} else {
    echo json_encode(['status'=>'error','message'=>'Failed to update']);
}

$stmt->close();
$conn->close();
?>
